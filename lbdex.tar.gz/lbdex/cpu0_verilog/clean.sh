rm -f dynstr dynsym global_offset so_func_offset libso.hex cpu0.hex cpu0Is cpu0IIs cpu0Id cpu0IId *~

