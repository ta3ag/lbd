#ifndef _CPU0CONFIG_H_
#define _CPU0CONFIG_H_

//#define ASM_EASY_PORTING

#endif

