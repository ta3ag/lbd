#include "a.h"

int foo4(void) {
  return 5;
}

int main() {
  return foo1();
}

