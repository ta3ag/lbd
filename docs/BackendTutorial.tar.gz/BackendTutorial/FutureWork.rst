Future Work
============

Major issue:
-------------

1. LLVM IDE setup in Xcode or Eclips. We don't know if it possible.

2. Cannot display Figure Number by :num:`FigureLink`.

3. Cannot display Section Number like Figure Number.


Minor issue: 
-------------

1. Cannot show figure description at center.

2. cannot set **bold** in literalinclude or code-block.

3. LaTeX issue: we still don't know the answer
	Chinese author name cannot appear in LaTeX, so Jonathan use .png file to 
	display Chinese name.
	Author name can be display on more than one line by \\and, but will shift a 
	little right on the second line.
	The Chinese name size is OK in html but too large in LaTeX.
