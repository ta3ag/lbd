
/// start
int foo(int x1, int x2)
{
  int sum = x1 + x2;
  
  return sum; 
}

int bar()
{
  return 5;
}

